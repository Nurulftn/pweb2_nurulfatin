
<?php $__env->startSection('title'); ?>
Detail Pegawai
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="app-content">
      <div class="app-title">
        <div class="div">
          <h1><i class="fa fa-laptop"></i> Detail User</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">User</li>
          <li class="breadcrumb-item"><a href="/user">Data User</a></li>
          <li class="breadcrumb-item"><a href="#">Detail User</a></li>
        </ul>
      </div>			
      <div class="tile">
        <div class="page-header">
          <div class="row">
            <div class="col-md-12">
				
            <table class="table-condensed">					
            	
				<tr>
					<td>Nama</td>
					<td>: </td>
					<td><?php echo e($user->name); ?></td>
				</tr>
				
				
				
				

				</tr>                               
					<td> Email</td>
					<td>:</td>
					<td><?php echo e($user->email); ?></td>
				</tr>                               
				
				
			</table>
            </div>            
          </div>
        </div>
      </div>

	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pemrograman-web\resources\views/user/show.blade.php ENDPATH**/ ?>