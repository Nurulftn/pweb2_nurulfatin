
<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i> Sistem Informasi | Dashboard</h1>
          <p>Dashboard SIMPEL</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-6 col-lg-3">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-users fa-3x"></i>
            <div class="info">
              <h4>Users</h4>
              <p><b><?php echo e($user); ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3"><a href="<?php echo e(route('pegawai.create')); ?>">
          <div class="widget-small info coloured-icon"><i class="icon fa fa-edit fa-3x"></i>
            <div class="info"></a>
              <h4>Tambah Data Engineering</h4>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3"><a href="<?php echo e(route('pegawai.index')); ?>">
          <div class="widget-small warning coloured-icon"><i class="icon fa fa-files-o fa-3x"></i>
            <div class="info"></a>
              <h4>Data Engineering</h4>
            </div>
          </div>
        </div>
        
        

      </div>
      
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Semester 4\Web II\pemrograman-web\resources\views/dashboard.blade.php ENDPATH**/ ?>