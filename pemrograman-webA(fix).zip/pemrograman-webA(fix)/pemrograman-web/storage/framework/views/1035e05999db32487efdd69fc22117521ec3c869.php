<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('template/docs/css/main.css')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="<?php echo e(url('https://fonts.googleapis.com/css2?family=Inter:wght@200;400;600;700;900&family=Poppins:wght@400;600;700&display=swap"
        rel="stylesheet')); ?>">

    <link rel="stylesheet" type="text/css"
        href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Login - SIMPEL</title>
</head>

<body>
    <section class="material-half-bg">
        <div class="cover"></div>
    </section>

    <section class="login-content" style="background-color:#FAAD14;">
        <div class="logo">
            <h1>SIMPEL</h1>
        </div>
        <div class="login-box">
            <form class="login-form" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo e(csrf_field()); ?>

                <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>SIGN IN</h3>
                <div class="form-group">
                    <label class="control-label">EMAIL</label>
                    <input class="form-control" id="login" type="text" name="login" placeholder="Username"
                        value="<?php echo e(old('login')); ?>" required autofocus>
                    <?php if($errors->has('login')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('login')); ?></strong>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label class="control-label">PASSWORD</label>
                    <input class="form-control" id="password" type="password" placeholder="Password" name="password"
                        required>
                </div>
                <div class="form-group">
                    <div class="utility">
                        
                        
                    </div>
                </div>
                <div class="form-group btn-container" >
                    <button type="submit" class="btn btn-primary btn-block" ><i
                            class="fa fa-sign-in fa-lg fa-fw" style=""></i>SIGN IN</button>
                </div>
            </form>
        </div>
    </section>

    <script src="<?php echo e(asset('template/docs/js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/docs/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/docs/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/docs/js/main.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('template/docs/js/plugins/chart.js')); ?>"></script>
    <script type="text/javascript">
        $('.login-content [data-toggle="flip"]').click(function() {
            $('.login-box').toggleClass('flipped');
            return false;
        });
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\pemrograman-web41(fix)\pemrograman-web\resources\views/auth/login.blade.php ENDPATH**/ ?>