<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AgamaController;
use App\Http\Controllers\ChartController;
use App\Http\Controllers\NegaraController;

use App\Http\Controllers\PegawaiController;

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\KeluargaController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PelatihanController;
use App\Http\Controllers\PendidikanController;
use App\Http\Controllers\PengalamanController;
use App\Http\Controllers\GolonganDarahController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::resource('user', UserController::class)->middleware('role:pimpinan');

Route::get('/dashboard', [DashboardController::class,'index']);
Route::resource('pegawai', PegawaiController::class);


Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    Route::get('pegawai/pdf', [PegawaiController::class,'pdf'])->name('pegawai-pdf');
    Route::get('pegawai/pdf', [PegawaiController::class,'pdf'])->name('pegawai-pdf');



require __DIR__.'/auth.php';
